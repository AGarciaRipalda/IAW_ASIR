<?php
/**
 * Configuración de Blizzard API
 * 
 * IMPORTANTE: Obtén tus credenciales en https://develop.battle.net/
 * 
 * Pasos:
 * 1. Crear cuenta en Blizzard Developer Portal
 * 2. Crear una nueva aplicación
 * 3. Copiar Client ID y Client Secret aquí
 */

// REEMPLAZA ESTOS VALORES CON TUS CREDENCIALES REALES
define('BLIZZARD_CLIENT_ID', '3d58ebcefb774f718a8f56fbec6e54aa');
define('BLIZZARD_CLIENT_SECRET', 'vWYN7D2hgR9ZlW2uD6XqcSsfXALx0z2T');

// Configuración regional (no modificar a menos que uses otra región)
define('BLIZZARD_REGION', 'eu');  // Opciones: us, eu, kr, tw, cn
?>